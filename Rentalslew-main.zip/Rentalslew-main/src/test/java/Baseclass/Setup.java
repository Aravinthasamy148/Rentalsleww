package Baseclass;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

public class Setup {
	static WebDriver driver;
	public static JavascriptExecutor js;
	public static FluentWait<WebDriver> wait;
	
	public void brower() throws Exception {
		
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		ChromeOptions options = new ChromeOptions();
		options.addArguments("-allow-origins", "http://127.0.0.1:45411/");
		//options.addArguments("--headless");
		options.addArguments("start-maximized");
		driver = new ChromeDriver(options);
		driver.get("https://demo1.rentalslew.com/login");
		Thread.sleep(5000);
		wait = new  WebDriverWait(driver, Duration.ofSeconds(3000));
		
		
	}	        

	
	public void registere() throws InterruptedException {
		driver.findElement(By.id("first_name")).sendKeys("sam");;
		driver.findElement(By.id("last_name")).sendKeys("sam");
		driver.findElement(By.id("username")).sendKeys("samsam");;
		
		// Create a Select object
        Select select = new Select(driver.findElement(By.id("user_type")));

         // Select an option by value
        select.selectByVisibleText("Traveller");
        
              
		driver.findElement(By.id("email2")).sendKeys("sam83@mailinator.com"); 
		WebElement chooseCoun = driver.findElement(By.xpath("//*[@id='register_form']/div[1]/div[6]/div/div/div/div"));
		chooseCoun.click();
		chooseCoun.sendKeys("India");
		chooseCoun.sendKeys(Keys.ENTER);
		driver.findElement(By.xpath("//input[@placeholder='Mobile Number']")).sendKeys("9003490760");
		
		 // Select an option by value
		 Thread.sleep(5000);
		 driver.findElement(By.id("dob")).click();
		  Select select1 = new Select(driver.findElement(By.className("yearselect")));
	      select1.selectByIndex(72);
	         
		 Select select3 = new Select(driver.findElement(By.className("monthselect")));
         select3.selectByIndex(7);
         Thread.sleep(5000);
 		List<WebElement>dates=driver.findElements(By.xpath("//table[@class='table-condensed']//tbody//tr//td"));
 		for (WebElement date : dates) {
 			String mname=date.getText();
 			if (mname.equalsIgnoreCase("15")) {
 				date.click(); 
 				break;
 			}}
 			
 			Thread.sleep(5000);
 			
 			WebElement apply = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//div/button)[12]")));
 			Thread.sleep(5000);
	        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", apply);
	        Actions act = new Actions(driver);
	        Thread.sleep(5000);
	        act.moveToElement(apply).click().build().perform();
	        Thread.sleep(3000);
 			 Select select2= new Select(driver.findElement(By.id("floatingSelect")));
 		        // Select an option by index (starting from 0)
 		        select2.selectByIndex(1);	
 		        
 		       driver.findElement(By.xpath("//input[@placeholder='password']")).sendKeys("Alonso@14");
 		       driver.findElement(By.xpath("//input[@placeholder='cpassword']")).sendKeys("Alonso@14");
 		       
 		       
 		       Thread.sleep(3000);
 		       WebElement ww = driver.findElement(By.xpath("//input[@type='checkbox']"));
 		      ((JavascriptExecutor) driver).executeScript("arguments[0].click();", ww);

 		       Thread.sleep(3000);
 		       driver.findElement(By.id("button")).click();
			
 		      Thread.sleep(3000);
 		      driver.findElement (By.xpath("//button[text()='Verify OTP']")).click();
	
 		     Thread.sleep(3000);
 		      driver.findElement(By.xpath("(//a[@class='nav-link '])[2]")).click();
 		     //kyc click
 		      Thread.sleep(3000);
 		     driver.findElement(By.xpath("//a[text()='I want to upload KYC']")).click();
 
 } 	
	    public void adminapprove() throws InterruptedException {
//	      driver.get("https://demo1.rentalslew.com/admin");
//	      driver.findElement(By.id("user-name")).sendKeys("admin@rentalslew.com");
//	      driver.findElement(By.id("user-password")).sendKeys("admin123");
//	      driver.findElement(By.xpath("//button[@type='submit']")).click();
//	      driver.findElement(By.xpath("((//a)[31]")).click();
	    
	    	//login
	      driver.findElement(By.id("username")).sendKeys("karii"); 
	      driver.findElement(By.id("passwords")).sendKeys("Kari@123");
	      driver.findElement(By.id("button1")).click();
	    
	     //Add listing
	      Thread.sleep(3000);
	      driver.findElement(By.xpath("(//a[@class='nav-link '])[2]")).click();
	     
	      //create new listing
	      driver.findElement(By.xpath("//h3[text()='Create a new listing']")).click();
	      
	      //Apartment
	      driver.findElement(By.id("Apartment_property_type")).click();
	      
	      driver.findElement(By.id("goNewListingTwo")).click();
	      
	      driver.findElement(By.id("Entire Place_property_type")).click();
	      
	      driver.findElement(By.id("goNewListingThree")).click();
	    
}


	}
