package Baseclass;

import org.testng.annotations.Test;

public class Main{

	@Test
	public void testmethods() throws Exception {
	Setup s1 = new Setup();
	s1.brower();
	//s1.registere();
	s1.adminapprove();
  }


}

